# Pitt MATH 3370 Mathematical Neuroscience Models

Need to flesh this out and learn markdown to make it look cool. Will update
with excessive emojis :brain:
